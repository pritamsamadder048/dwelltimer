from miflora.miflora_poller import MiFloraPoller,MI_CONDUCTIVITY, MI_MOISTURE, MI_LIGHT, MI_TEMPERATURE, MI_BATTERY
print("Trying to connect ....")
poller = MiFloraPoller("C4:7C:8D:63:81:E2",adapter='hci1')
print("Getting data from Mi Flora")
while(True):
	print("FW: {}".format(poller.firmware_version()))
	#print("fetching name")
	print("Name: {}".format(poller.name()))
	#print("fetching temperature")
	print("Temperature: {}".format(poller.parameter_value(MI_TEMPERATURE,read_cached=False)))
	#print("fetching Moisture")
	print("Moisture: {}".format(poller.parameter_value(MI_MOISTURE,read_cached=False)))
	#print("fetching Light")
	print("Light: {}".format(poller.parameter_value(MI_LIGHT,read_cached=False)))
	#print("fetching Conductivity")
	print("Conductivity: {}".format(poller.parameter_value(MI_CONDUCTIVITY,read_cached=False)))
	#print("fetching Battery")
	print("Battery: {}".format(poller.parameter_value(MI_BATTERY,read_cached=False)))

